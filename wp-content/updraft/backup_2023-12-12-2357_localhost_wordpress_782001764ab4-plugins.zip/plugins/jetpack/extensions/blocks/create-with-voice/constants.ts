export const JETPACK_CREATE_WITH_VOICE_EXTENSION = 'create-with-voice' as const;
