interface Window {
	Jetpack_Editor_Initial_State: {
		siteLocale: string;
		adminUrl: string;
		available_blocks: {
			'jetpack/ai-assistant-support': boolean;
		};
	};
}
