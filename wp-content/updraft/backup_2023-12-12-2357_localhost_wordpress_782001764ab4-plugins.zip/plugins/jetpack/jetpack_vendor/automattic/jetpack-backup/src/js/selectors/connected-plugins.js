const connectedPluginsSelectors = {
	getConnectedPlugins: state => state.connectedPlugins || [],
};

export default connectedPluginsSelectors;
